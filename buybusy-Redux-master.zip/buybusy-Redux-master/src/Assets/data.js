// data of all the product's in home page
// id, name, image url , price and category of the product

export const data = [
  {
    id: "1",
    name: "Men's Round Neck Cotton Blend Black T-Shirt",
    image:
      "https://rukminim1.flixcart.com/image/416/416/xif0q/t-shirt/t/e/0/l-st-theboys-black-smartees-original-imagnqszzzzyuzru.jpeg?q=70",
    price: 199,
    category: "men",
  },
  {
    id: "2",
    name: "Men's Printed Casual Shirt",
    image:
      "https://rukminim1.flixcart.com/image/832/832/l2xmqvk0/shirt/z/i/x/m-ad-egypt-shirt-02-ak-impex-original-image5xzxaazchh8.jpeg?q=70",
    price: 399,
    category: "men",
  },
  {
    id: "3",
    name: "Men's Slim Fit Black Stretch Jeans",
    image: "https://m.media-amazon.com/images/I/61VYhbu1a-L._UX466_.jpg",
    price: 799,
    category: "men",
  },
  {
    id: "4",
    name: "boAt Rockerz450 Bluetooth On Ear Headphones with Mic",
    image: "https://m.media-amazon.com/images/I/51xxA+6E+xL._SX522_.jpg",
    price: 1999,
    category: "electric",
  },
  {
    id: "5",
    name: "Cuban Silver Bracelet for Men Boys",
    image: "https://m.media-amazon.com/images/I/512hvqlxOuL._UY625_.jpg",
    price: 2199,
    category: "jewellery",
  },
  {
    id: "6",
    name: "Laptop Backpack with USB Charging Port | Multi functional Bagpack (Grey)",
    image: "https://m.media-amazon.com/images/I/51rga1GR6rL.jpg",
    price: 1099,
    category: "men",
  },
  {
    id: "7",
    name: "Noise Twist Bluetooth Calling Smart Watch ",
    image: "https://m.media-amazon.com/images/I/61TapeOXotL._SX679_.jpg",
    price: 2199,
    category: "electric",
  },
  {
    id: "8",
    name: "HP All-in-One Desktop PC (8GB/256GB SSD + 1TB HDD/FHD",
    image: "https://m.media-amazon.com/images/I/61ogPth2lzL._SX679_.jpg",
    price: 45999,
    category: "electric",
  },
  {
    id: "9",
    name: "Women's Hoodies",
    image: "https://m.media-amazon.com/images/I/51CbQi8QLzL._UX466_.jpg",
    price: 2999,
    category: "women",
  },
  {
    id: "10",
    name: " Women's Sweatshirt 'M' size Pink ",
    image: "https://m.media-amazon.com/images/I/71eq6q3uVeL._AC_UY1100_.jpg",
    price: 3499,
    category: "women",
  },
  {
    id: "11",
    name: "Gold Jewellery Set necklace and earrings",
    image: "https://m.media-amazon.com/images/I/41L6gVqjhQL._AC_UL400_.jpg",
    price: 25499,
    category: "jewellery",
  },
  {
    id: "12",
    name: "Women Leather Bag",
    image: "https://m.media-amazon.com/images/I/71Y32csE9vL._UY695_.jpg",
    price: 4449,
    category: "women",
  },
  {
    id: "13",
    name: "WildHorn Wallet for Men",
    image: "https://m.media-amazon.com/images/I/914s7a8twcL._SX679_.jpg",
    price: 649,
    category: "men",
  },
  {
    id: "14",
    name: "HP Wired Keyboard",
    image:
      "https://m.media-amazon.com/images/I/31-AngJwVkL._SX300_SY300_QL70_FMwebp_.jpg",
    price: 599,
    category: "electric",
  },
  {
    id: "15",
    name: "Fujifilm Instax Mini 11",
    image:
      "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQCvQ0NoZVQ4XPDPIFWI9EjVeVX0a590vHlHg&usqp=CAU",
    price: 5499,
    category: "camera",
  },

  {
    id: "16",
    name: "Logitech Wireless Mouse",
    image:
      "https://bansalstationers.com/cdn/shop/products/image_101ac7b7-c5e6-4948-b137-fb0b6d49d8ca_554x554.jpg?v=1590934646",
    price: 799,
    category: "computer accessories",
  },
  {
    id: "17",
    name: "Samsung 24-inch Monitor",
    image:
      "https://5.imimg.com/data5/SELLER/Default/2022/10/CQ/NA/QR/48820468/samsung-led-monitor-24-inch-f24t352.jpg",
    price: 2199,
    category: "computer peripherals",
  },
  {
    id: "18",
    name: "Sony Noise Cancelling Headphones",
    image:
      "https://rukminim2.flixcart.com/image/850/1000/xif0q/headphone/e/h/c/-original-imagj85kjhaws9zx.jpeg?q=90&crop=false",
    price: 2499,
    category: "audio",
  },
  {
    id: "19",
    name: "Dell Inspiron Laptop",
    image:
      "https://m.media-amazon.com/images/I/51Zl9TAM8kL._AC_UF1000,1000_QL80_.jpg",
    price: 47999,
    category: "laptop",
  },
  {
    id: "20",
    name: "TP-Link Archer C6 Router",
    image: "https://i.ytimg.com/vi/CcknjHQ4Np0/maxresdefault.jpg",
    price: 1799,
    category: "networking",
  },
  {
    id: "21",
    name: "Canon PIXMA Wireless Printer",
    image:
      "https://m.media-amazon.com/images/I/81dCrZLRh-L._AC_UF894,1000_QL80_.jpg",
    price: 3999,
    category: "printers",
  },
  {
    id: "22",
    name: "Seagate Portable External Hard Drive",
    image:
      "https://spcpshop.in/cdn/shop/products/seagate_expansion_1T_1_711cbd1f-b682-4bf7-b0fa-a68fd637bb9b_300x300.jpg?v=1580291241",
    price: 5499,
    category: "storage",
  },
  {
    id: "23",
    name: "Xbox Wireless Controller",
    image:
      "https://xxboxnews.blob.core.windows.net/prod/sites/2/2024/01/Vapor-Series-fe6e5a54e868df38b9c3.jpg",
    price: 4499,
    category: "gaming",
  },
  {
    id: "24",
    name: "Apple AirPods Pro",
    image:
      "https://www.jiomart.com/images/product/original/493177748/apple-airpods-pro-2nd-gen-with-magsafe-charging-case-white-digital-o493177748-p593697204-5-202209100128.jpeg?im=Resize=(420,420)",
    price: 20999,
    category: "audio",
  },
  {
    id: "25",
    name: "Lenovo IdeaPad Gaming Laptop",
    image:
      "https://p4-ofp.static.pub/fes/cms/2022/09/26/da8tws15p6155h2m5bfn8oxc3jpmpr766724.jpg",
    price: 60999,
    category: "laptop",
  },
  {
    id: "26",
    name: "LG 4K Ultra HD Smart LED TV",
    image:
      "https://www.lg.com/eg_en/images/tvs/md07581172/md07581172-260x260.jpg",
    price: 59999,
    category: "tv",
  },
  {
    id: "27",
    name: "JBL Flip 5 Bluetooth Speaker",
    image:
      "https://images-cdn.ubuy.co.in/658226e54974ff660b0b2242-jbl-flip-5-black-bluetooth-speaker.jpg",
    price: 8999,
    category: "audio",
  },
  {
    id: "28",
    name: "Samsung Galaxy Tab S7",
    image: "https://cdn.mos.cms.futurecdn.net/LpkKpSgnR94URppWhDanN5.jpg",
    price: 49999,
    category: "tablet",
  },
  {
    id: "29",
    name: "WD Elements Desktop External Hard Drive",
    image:
      "https://media.techeblog.com/images/western-digital-18tb-elements-desktop-external-hard-drive.jpg",
    price: 9999,
    category: "storage",
  },
  {
    id: "30",
    name: "Sony Bravia 55-inch 4K UHD Smart TV",
    image:
      "https://m.media-amazon.com/images/I/8159EvuNJaL._AC_UF1000,1000_QL80_.jpg",
    price: 79999,
    category: "tv",
  },
  {
    id: "31",
    name: "Canon EOS 200D II DSLR Camera",
    image:
      "https://ph.canon/media/image/2019/04/09/de0130cfff5d4e8c98b2c19dab7963aa_EOS+200D+MKII+SL+Front+Slant.png",
    price: 53990,
    category: "camera",
  },
  {
    id: "32",
    name: "Apple MacBook Air",
    image:
      "https://store.storeimages.cdn-apple.com/4668/as-images.apple.com/is/macbookair-og-202402?wid=1200&hei=630&fmt=jpeg&qlt=95&.v=1707414684423",
    price: 92900,
    category: "laptop",
  },
  {
    id: "33",
    name: "Bose SoundLink Color Bluetooth Speaker",
    image:
      "https://assets.bose.com/content/dam/Bose_DAM/Web/consumer_electronics/global/products/speakers/soundlink_color_ii/new_brand/soundlink_color_ii_citron_OV_02.psd/jcr:content/renditions/cq5dam.web.320.320.png",
    price: 11499,
    category: "audio",
  },
  {
    id: "34",
    name: "Samsung Galaxy Watch Active 2",
    image:
      "https://img.global.news.samsung.com/in/wp-content/uploads/2020/07/top.jpg",
    price: 20990,
    category: "wearable",
  },
  {
    id: "35",
    name: "Dell UltraSharp 27-inch Monitor",
    image:
      "https://i.dell.com/is/image/DellContent/content/dam/ss2/product-images/dell-client-products/peripherals/monitors/u-series/u2724d/media-gallery/monitor-ultrasharp-u2724d-qhd-gy-gallery-1.psd?fmt=png-alpha&pscan=auto&scl=1&hei=804&wid=914&qlt=100,1&resMode=sharp2&size=914,804&chrss=full",
    price: 34299,
    category: "computer peripherals",
  },
  {
    id: "36",
    name: "Logitech G Pro X Gaming Headset",
    image:
      "https://images-cdn.ubuy.co.in/633aa494c8050522204deafa-logitech-g-pro-x-gaming-headset-blue.jpg",
    price: 11995,
    category: "gaming",
  },
  {
    id: "37",
    name: "OnePlus 8T 5G",
    image: "https://www.addmecart.com/wp-content/uploads/2022/11/Op11-1.jpg",
    price: 42999,
    category: "phone",
  },
  {
    id: "38",
    name: "LG 29-inch UltraWide Monitor",
    image: "https://viphouse.rs/products/37427/8006.jpg",
    price: 18999,
    category: "computer peripherals",
  },
  {
    id: "39",
    name: "Amazon Echo Dot (4th Gen)",
    image: "https://m.media-amazon.com/images/I/51xzFbSLkUL._AC_SY350_.jpg",
    price: 4499,
    category: "smart home",
  },
  {
    id: "40",
    name: "Razer DeathAdder Elite Gaming Mouse",
    image:
      "https://www.skyland.com.bd/image/cache/catalog/DeathAdder-Essential-320x320.jpg",
    price: 3999,
    category: "gaming",
  },
  {
    id: "41",
    name: "Apple iPad Air (4th Generation)",
    image:
      "https://www.apple.com/newsroom/images/product/ipad/standard/apple_new-ipad-air_new-design_09152020.jpg.news_app_ed.jpg",
    price: 54900,
    category: "tablet",
  },
  {
    id: "42",
    name: "Samsung 32-inch Curved Monitor",
    image:
      "https://images-cdn.ubuy.co.in/64c7b0bb1e9aeb0cbd15b788-samsung-32-class-curved-full-hd-1-920-x.jpg",
    price: 14999,
    category: "computer peripherals",
  },
  {
    id: "43",
    name: "Sony WH-1000XM4 Wireless Noise Cancelling Headphones",
    image:
      "https://store.sony.com.au/dw/image/v2/ABBC_PRD/on/demandware.static/-/Sites-sony-master-catalog/default/dw015f9ecb/images/WH1000XM4B/WH1000XM4B_3.png?sw=442&sh=442&sm=fit",
    price: 28990,
    category: "audio",
  },
  {
    id: "44",
    name: "Microsoft Surface Pro 7",
    image: "https://m.media-amazon.com/images/I/51TaFqs1NEL.jpg",
    price: 76990,
    category: "laptop",
  },
  {
    id: "45",
    name: "Logitech C922 Pro Stream Webcam",
    image:
      "https://5.imimg.com/data5/SELLER/Default/2020/10/AQ/SX/TE/1112556/logitech-c922-pro-stream-webcam-with-tripod.jpeg",
    price: 13499,
    category: "camera",
  },
  {
    id: "46",
    name: "LG Tone Free FN7 True Wireless Earbuds",
    image:
      "https://www.lg.com/au/images/headphones/md07519405/gallery/FN7_01_new-v2.jpg",
    price: 17990,
    category: "audio",
  },
  {
    id: "47",
    name: "Canon EOS 90D DSLR Camera",
    image:
      "https://5.imimg.com/data5/SELLER/Default/2020/10/LM/LD/GR/99164088/canon-eos-90d-18-135mm-is-usm-500x500.jpeg",
    price: 92990,
    category: "camera",
  },
  {
    id: "48",
    name: "Bose QuietComfort 35 II Wireless Headphones",
    image:
      "https://images-cdn.ubuy.co.in/635ab82b3dbb9710615f144a-bose-quietcomfort-35-series-ii-wireless.jpg",
    price: 29990,
    category: "audio",
  },
  {
    id: "49",
    name: "Asus TUF Gaming A15 Laptop",
    image:
      "https://m.media-amazon.com/images/I/91zVSkGGZbS._AC_UF1000,1000_QL80_.jpg",
    price: 78990,
    category: "laptop",
  },
  {
    id: "50",
    name: "Mi Smart Band 5",
    image:
      "https://image.hurimg.com/i/hurriyet/75/750x422/5f0e89eb7af50715943a4304.jpg",
    price: 2499,
    category: "wearable",
  },
  {
    id: "51",
    name: "Raspberry Pi 4 Model B",
    image:
      "https://assets.raspberrypi.com/static/raspberry-pi-4-labelled-f5e5dcdf6a34223235f83261fa42d1e8.png",
    price: 4499,
    category: "computer accessories",
  },
  {
    id: "52",
    name: "JBL Boombox Portable Bluetooth Speaker",
    image:
      "https://images-cdn.ubuy.co.in/634e6d95b0f1162fe866b8d0-jbl-boombox-2-wireless-jbl-bluetooth.jpg",
    price: 23990,
    category: "audio",
  },
  {
    id: "53",
    name: "Sony PlayStation DualSense Wireless Controller",
    image: "https://m.media-amazon.com/images/I/61u6pfUsBBS.jpg",
    price: 5290,
    category: "gaming",
  },
  {
    id: "54",
    name: "Microsoft Xbox Series X",
    image:
      "https://images-cdn.ubuy.co.in/64e2891833d8e94ac679d05f-2022-newest-xbox-series-x-gaming.jpgg",
    price: 49990,
    category: "gaming",
  },
  {
    id: "55",
    name: "Logitech MX Master 3 Wireless Mouse",
    image:
      "https://5.imimg.com/data5/SELLER/Default/2021/5/UY/UF/BZ/117485675/logitech-mx-master-3-wireless-mouse-500x500.jpg",
    price: 7995,
    category: "computer accessories",
  },
  {
    id: "56",
    name: "Amazon Kindle Paperwhite",
    image:
      "https://m.media-amazon.com/images/G/31/kindle/journeys/nNgy62TSAuW8OTbBaQmF4ntGWPnOiLmMI2F1M2Fskb2BZA3D/ZjA5NGI3ODMt._CB641349947_.jpg",
    price: 12499,
    category: "e-readers",
  },
  {
    id: "57",
    name: "HP Pavilion 27-inch Monitor",
    image:
      "https://images-cdn.ubuy.co.in/633af8a8cdb35f62be1da197-hp-pavilion-27-inch-all-in-one-desktop.jpg",
    price: 22999,
    category: "computer peripherals",
  },
  {
    id: "58",
    name: "Nikon D3500 DSLR Camera",
    image:
      "https://5.imimg.com/data5/ANDROID/Default/2023/11/361028496/WQ/YQ/KH/53454298/product-jpeg.jpg",
    price: 43990,
    category: "camera",
  },
  {
    id: "59",
    name: "Sony HT-RT40 Real 5.1ch Dolby Digital Soundbar Home Theatre System",
    image:
      "https://5.imimg.com/data5/SELLER/Default/2020/11/YK/JS/GY/79655529/woofer-home-theatre-500x500.jpg",
    price: 18990,
    category: "audio",
  },
  {
    id: "60",
    name: "Garmin Forerunner 245 Music",
    image:
      "https://www.garmin.co.in/m/in/g/products/forerunner245Music-aqua-image-01.png",
    price: 29990,
    category: "wearable",
  },
  {
    id: "61",
    name: "GoPro HERO9 Black",
    image:
      "https://images-cdn.ubuy.co.in/64492c8d30101d0dce142f5f-gopro-hero9-black-waterproof-action.jpg",
    price: 38990,
    category: "camera",
  },
  {
    id: "62",
    name: "Fitbit Charge 4",
    image: "https://cdn.mos.cms.futurecdn.net/vKTibDZTLhymSM88cLxUXN.jpg",
    price: 9999,
    category: "wearable",
  },
  {
    id: "63",
    name: "Canon EOS 1500D DSLR Camera",
    image:
      "https://in.canon/media/image/2018/03/25/53849be12b66400498ed3b55bc9fae12_eos-1500d_b2.png",
    price: 29990,
    category: "camera",
  },
];
