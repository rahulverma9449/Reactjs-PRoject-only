// react router
import { createBrowserRouter, RouterProvider } from "react-router-dom";

// all the pages and component to render
import Navbar from "./Component/Navbar/Navbar";
import { About } from "./Pages/About.1";
import { Cart } from "./Pages/Cart";
import { Error } from "./Pages/Error";
import { Home } from "./Pages/Home";
import { MyOrder } from "./Pages/MyOrder";
import { SignIn } from "./Pages/SignIn";
import { SignUp } from "./Pages/SignUp";

// main app function
function App() {
  // all the link routes
  const router = createBrowserRouter([
    {
      path: "/",
      element: <Navbar />,
      errorElement: <Error />,
      children: [
        { index: true, element: <Home /> },
        { path: "/myorder", element: <MyOrder /> },
        { path: "/cart", element: <Cart /> },
        { path: "/about", element: <About /> },
        { path: "/signin", element: <SignIn /> },
        { path: "/signup", element: <SignUp /> },
      ],
    },
  ]);

  return (
    <>
      {/* routes */}
      <RouterProvider router={router} />
    </>
  );
}

export default App;
