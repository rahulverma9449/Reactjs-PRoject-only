const PrivacyMessage = () => {
  return <p className="lead mb-4">Counter is Private !!!!!!!!!</p>;
};

export default PrivacyMessage;
