import { useContext, useEffect, useState } from "react"; // Import React
import { PostList as PostListData } from "../../Store/post-list-store"; // Import PostList context
import WelcomeMessage from "../WelcomeMessage/WelcomeMessage";
import Post from "./Post"; // Import Post component

const PostList = () => {
  const { postList, addInitialPosts } = useContext(PostListData); // Destructure postList from context

  const [fetching, setFetching] = useState(false);

  useEffect(() => {
    setFetching(true);
    fetch("https://dummyjson.com/posts")
      .then((res) => res.json())
      .then((data) => {
        addInitialPosts(data.posts);
        setFetching(false);
      });
    return () => {
      console.log("Cleaning up UseEffect.");
    };
  }, []);

  return (
    <>
      {fetching && <LoadingSpinner />}
      {!fetching && postList.length === 0 && <WelcomeMessage />}
      {fetching && postList.map((post) => <Post key={post.id} post={post} />)}
    </>
  );
};

export default PostList; // Export PostList component
