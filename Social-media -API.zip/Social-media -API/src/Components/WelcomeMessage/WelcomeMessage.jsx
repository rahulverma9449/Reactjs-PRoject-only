const WelcomeMessage = ({ onGetPostsClick }) => {
  return (
    <center>
      <h1 className="welcome-message">OOOPSS!! There are no posts</h1>
    </center>
  );
};
export default WelcomeMessage;
